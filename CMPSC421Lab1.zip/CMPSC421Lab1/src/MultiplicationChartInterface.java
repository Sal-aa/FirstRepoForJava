public interface MultiplicationChartInterface {
    void displayChart();


}
